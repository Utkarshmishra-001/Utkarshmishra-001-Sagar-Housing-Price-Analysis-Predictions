import pandas as pd
import numpy as np
import os

# Set seed for reproducibility
np.random.seed(42)

# Define localities and their base price per sqft
localities = {
    'Makroniya': 3000,
    'Tilli': 4500,
    'Gopal Ganj': 9000,
    'Kakaganj': 12000,
    'Bhagwan Ganj': 8000,
    'Moti Nagar': 10000,
    'Civil Lines': 8500,
    'Cantt': 7500,
    'Sagar Cantt': 7000,
    'Subhash Nagar': 4000,
    'Vijay Nagar': 3500
}

def generate_data(n_samples=500):
    data = []
    
    loc_names = list(localities.keys())
    
    for _ in range(n_samples):
        loc = np.random.choice(loc_names)
        base_price = localities[loc]
        
        # Area in sqft
        area = np.random.randint(600, 4000)
        
        # BHK based on area
        if area < 1000:
            bhk = np.random.choice([1, 2])
        elif area < 2000:
            bhk = np.random.choice([2, 3])
        elif area < 3000:
            bhk = np.random.choice([3, 4])
        else:
            bhk = np.random.choice([4, 5, 6])
            
        # Bathrooms
        bathrooms = max(1, bhk - np.random.randint(0, 2))
        
        # Age of property (0 to 30 years)
        age = np.random.randint(0, 31)
        
        # Price calculation with some noise
        # Base price per sqft + BHK bonus + Bathroom bonus - Age penalty
        price_per_sqft = base_price * (1 + (bhk * 0.05) + (bathrooms * 0.02) - (age * 0.005))
        # Add random noise
        price_per_sqft *= np.random.uniform(0.9, 1.1)
        
        price_total = (price_per_sqft * area) / 100000 # In Lakhs
        
        data.append({
            'Location': loc,
            'Area_sqft': area,
            'BHK': bhk,
            'Bathrooms': bathrooms,
            'Age_Years': age,
            'Price_Lakhs': round(price_total, 2)
        })
        
    return pd.DataFrame(data)

if __name__ == "__main__":
    df = generate_data(800)
    output_path = 'sagar_housing_data.csv'
    df.to_csv(output_path, index=False)
    print(f"Generated {len(df)} records and saved to {output_path}")
    print(df.head())
