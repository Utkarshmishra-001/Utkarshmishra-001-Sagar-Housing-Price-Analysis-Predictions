import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import joblib
import json

# Load data
df = pd.read_csv('sagar_housing_data.csv')

# Preprocessing
le = LabelEncoder()
df['Location_Encoded'] = le.fit_transform(df['Location'])

# Store mapping for frontend
location_mapping = dict(zip(le.classes_, range(len(le.classes_))))

# Features and target
X = df[['Location_Encoded', 'Area_sqft', 'BHK', 'Bathrooms', 'Age_Years']]
y = df['Price_Lakhs']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Accuracy
score = model.score(X_test, y_test)
print(f"Model R^2 Score: {score:.4f}")

# Save model and mapping
joblib.dump(model, 'housing_model.pkl')
joblib.dump(le, 'label_encoder.pkl')

# Generate stats for dashboard
stats = {
    'avg_price': round(df['Price_Lakhs'].mean(), 2),
    'max_price': round(df['Price_Lakhs'].max(), 2),
    'min_price': round(df['Price_Lakhs'].min(), 2),
    'localities': list(le.classes_),
    'avg_price_per_loc': df.groupby('Location')['Price_Lakhs'].mean().to_dict(),
    'r2_score': round(score, 4)
}

with open('stats.json', 'w') as f:
    json.dump(stats, f)

print("Analysis complete. Model and stats saved.")
